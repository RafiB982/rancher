@cython.cclass
class Function:
    @cython.ccall
    def evaluate(self, x: float) -> float:
        return 0
