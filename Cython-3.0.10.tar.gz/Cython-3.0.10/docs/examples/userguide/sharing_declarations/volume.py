def cube(x):
    return x * x * x
