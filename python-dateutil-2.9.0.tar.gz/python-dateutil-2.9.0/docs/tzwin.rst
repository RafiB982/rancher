======
tz.win
======

.. py:currentmodule:: dateutil.tz.win

.. automodule:: dateutil.tz.win

Classes
-------

.. autoclass:: tzres
    :members:

.. autoclass:: tzwin
    :members: list, display, transitions
    :undoc-members:

.. autoclass:: tzwinlocal
    :members: display, transitions
    :undoc-members:

