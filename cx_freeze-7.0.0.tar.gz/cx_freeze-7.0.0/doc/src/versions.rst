Versions of cx_Freeze
=====================

.. list-table::
   :header-rows: 1
   :widths: 300 300 200

   * - cx_Freeze version
     - Python version
     - Status
   * - cx_Freeze 7.0
     - Python 3.8 to 3.12
     - supported
   * - cx_Freeze 6.14 and 6.15
     - Python 3.7 to 3.11
     - supported
   * - cx_Freeze 6.9 to 6.13
     - Python 3.6 to 3.10
     - supported
   * - cx_Freeze 6.4 to 6.8
     - Python 3.6 to 3.9
     - unsupported
   * - cx_Freeze 6.1 to 6.3
     - Python 3.5 to 3.8
     - unsupported
   * - cx_Freeze 6.0
     - Python 3.5 to 3.7
     - unsupported
   * - cx_Freeze 5.1.1
     - Python 2.7
     - unsupported
