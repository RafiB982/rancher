# Samples

Here are samples to test cx_Freeze or to show how to use a package in cx_Freeze.

# Installation and requirements:

In a virtual environment, install by issuing the command:

```
pip install -U cx_Freeze "backports.zoneinfo;python_version<'3.9'" "tzdata;sys_platform=='win32'"
```
